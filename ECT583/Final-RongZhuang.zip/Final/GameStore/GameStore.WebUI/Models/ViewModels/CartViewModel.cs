﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GameStore.WebUI.Models
{
    public class CartViewModel
    {
        public int Id { get; set; }
        public int Quantity { get; set; }
    }
}