package example.identification;

public interface Identifiable {

    String getIdentifier();
    
}
